$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "Jarvis\Jarvis.csproj"
dotnet restore $project
dotnet publish $project -c Release -r win-x64 --self-contained true
Write-Host "`nСборка завершена. Найди Jarvis.exe в папке Jarvis\bin\Release\."
